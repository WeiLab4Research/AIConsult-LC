#' Risk Predictions from Lung Cancer Models
#'
#' The R package provides and visualizes individual risks of lung cancer
#' based on various published papers: Bach et al., 2003; Spitz et al., 2007;
#' Hoggart et al., 2012; Tammemagi et al., 2013 (PLCOm2012); Park et al., 2013 (Korean Men);
#' Tammemagi et al., 2014 (PLCOall2014); Wilson and Weissfeld, 2015 (Pittsburgh); Marcus et al., 2015 (LLPi);
#' Katki et al., 2016 (LCRAT); Markaki et al., 2018 (HUNT); Field et al., 2021 (LLPv3);
#' Na et al., 2023 (LCRS); Pan et al., 2023 (OWL).
#'
#' @section Warning:
#'  xgboost, survival, Matrix and ggplot2 are required dependency of this package.
#'  xgboost, survival, Matrix and ggplot2 may automatically be installed the first time this package is used.
#'  Inputs must be in numerical format to ensure correct output.
#'  For data frame x, this can be checked using sapply(x,class)
#'
#' @param x A data frame or matrix containing one individual's covariate values.
#'  The data frame or matrix must contain only one row and the covariates must be
#'  in the following columns and numerical formats:
#'
#'  \itemize{
#'  \item column 1 - current age (numeric);
#'  \item column 2 - gender (1=Female, 0=Male);
#'  \item column 3 - smoking status (0=never smoker, 1=former smoker, 2=current smoker);
#'  \item column 4 - years smoked (numeric);
#'  \item column 5 - years quit (numeric; NA for never smokers and current smokers);
#'  \item column 6 - cigarettes per day (numeric);
#'  \item column 7 - race (0=Non-hispanic white,
#'                   1=Non-hispanic Black/African American,
#'                   2=Hispanic,
#'                   3=Other Ethnicity);
#'  \item column 8 - prior history of Emphysema (1=Yes,0=No);
#'  \item column 9 - number of first degree relatives with lung cancer (0,1,2);
#'  \item column 10 - bmi;
#'  \item column 11 - highest education level (0=elementary school or lower,
#'                                       1=middle school,
#'                                       2=HS graduate,
#'                                       3=post hs, no college,
#'                                       4=associate degree/some college,
#'                                       5=bachelors degree,
#'                                       6=graduate school);
#'  \item column 12 - asbestos exposure (1=Yes,0=No);
#'  \item column 13 - prior history of pneumonia (1=Yes,0=No);
#'  \item column 14 - prior history of cancer (1=Yes,0=No);
#'  \item column 15 - family history of lung cancer (0=none, 1=early onset, 2=late onset);
#'  \item column 16 - prior history of copd (1=Yes,0=No);
#'  \item column 17 - dust exposure  (1=Yes,0=No);
#'  \item column 18 - 2 or more first degree relatives with cancer (binary indicator);
#'  \item column 19 - 1 or more first degree relatives with smoking cancer (binary indicator);
#'  \item column 20 - no hay fever (1=No Hay Fever,0=Yes Hay Fever);
#'  \item column 21 - asian ethnicity (1=Yes,0=No);
#'  \item column 22 - islander ethnicity (1=Yes,0=No));
#'  \item column 23 - American indian ethnicity (1=Yes,0=No);
#'  \item column 24 - environment tabacco smoke (1=Yes,0=No);
#'  \item column 25 - indoor smoke exposure in hours (numeric);
#'  \item column 26 - prior history of chronic bronchitis (1=Yes,0=No);
#'  \item column 27 - physical activity level (0=No;
#'                    1 = ≤4 times/week at ＜30 minutes/session;
#'                    2 = 2–4 times/week at ≥30 minutes/session or ≥5 times/week at ＜30 minutes/session;
#'                    3 = ≥5 times/week at ≥30 minutes/ session)
#'  \item column 28 - exercising for less than a minimum of 30 minutes 3 times a week(1=Yes,0=No);
#'  \item column 29 - prior history of diabetes (1=Yes,0=No);
#'  \item column 30 - fasting glucose levels, mg/dl (numeric);
#'  \item column 31 - cough daily during periods of the year (1=Yes,0=No);
#'  \item column 32 - height, cm (numeric);
#'  \item column 33 - residential area (0=rural; 1=urban);
#'  \item column 34 - frequent coughing during the day or at night (lasting 3 months or more) in the past 12 months (1=Yes,0=No);
#'  \item column 35 - smoking inhalation to the lungs (1=Yes,0=No).
#'  }
#'
#' @return A circular figure showing the absolute risk and risk level predicted by each model.
#'
#' @references
#' \itemize{
#'  \item Bach PB, Kattan MW, Thornquist MD, et al.
#'        Variations in lung cancer risk among smokers. J Natl Cancer Inst. 2003;95(6):470-478. doi:10.1093/jnci/95.6.470
#'  \item Spitz MR, Hong WK, Amos CI, et al.
#'        A risk model for prediction of lung cancer. J Natl Cancer Inst. 2007;99(9):715-726. doi:10.1093/jnci/djk153
#'  \item Hoggart C, Brennan P, Tjonneland A, et al.
#'        A risk model for lung cancer incidence. Cancer Prev Res (Phila). 2012;5(6):834-846. doi:10.1158/1940-6207.CAPR-11-0237
#'  \item Tammemägi MC, Katki HA, Hocking WG, et al.
#'        Selection criteria for lung-cancer screening. N Engl J Med. 2013;368(8):728-736. doi:10.1056/NEJMoa1211776
#'  \item Park S, Nam BH, Yang HR, et al.
#'        Individualized risk prediction model for lung cancer in Korean men. PLoS One. 2013;8(2):e54823. doi:10.1371/journal.pone.0054823
#'  \item Tammemägi MC, Church TR, Hocking WG, et al.
#'        Evaluation of the lung cancer risks at which to screen ever- and never-smokers: screening rules applied to the PLCO and NLST cohorts. PLoS Med. 2014;11(12):e1001764. Published 2014 Dec 2. doi:10.1371/journal.pmed.1001764
#'  \item Wilson DO, Weissfeld J.
#'        A simple model for predicting lung cancer occurrence in a lung cancer screening program: The Pittsburgh Predictor. Lung Cancer. 2015;89(1):31-37. doi:10.1016/j.lungcan.2015.03.021
#'  \item Marcus MW, Chen Y, Raji OY, Duffy SW, Field JK.
#'        LLPi: Liverpool Lung Project Risk Prediction Model for Lung Cancer Incidence. Cancer Prev Res (Phila). 2015;8(6):570-575. doi:10.1158/1940-6207.CAPR-14-0438
#'  \item Katki HA, Kovalchik SA, Berg CD, Cheung LC, Chaturvedi AK.
#'        Development and Validation of Risk Models to Select Ever-Smokers for CT Lung Cancer Screening. JAMA. 2016;315(21):2300-2311. doi:10.1001/jama.2016.6255
#'  \item Markaki M, Tsamardinos I, Langhammer A, Lagani V, Hveem K, Røe OD.
#'        A Validated Clinical Risk Prediction Model for Lung Cancer in Smokers of All Ages and Exposure Types: A HUNT Study. EBioMedicine. 2018;31:36-46. doi:10.1016/j.ebiom.2018.03.027
#'  \item Field JK, Vulkan D, Davies MPA, Duffy SW, Gabe R.
#'        Liverpool Lung Project lung cancer risk stratification model: calibration and prospective validation. Thorax. 2021;76(2):161-168. doi:10.1136/thoraxjnl-2020-215158
#'  \item Ma Z, Lv J, Zhu M, et al.
#'        Lung cancer risk score for ever and never smokers in China. Cancer Commun (Lond). 2023;43(8):877-895. doi:10.1002/cac2.12463
#'  \item Pan Z, Zhang R, Shen S, et al.
#'        OWL: an optimized and independently validated machine learning prediction model for lung cancer screening based on the UK Biobank, PLCO, and NLST populations. EBioMedicine. 2023;88:104443. doi:10.1016/j.ebiom.2023.104443
#'
#' }
#'
#'
#' @export
#' @examples
#' age <- c(66, 58, 75, 72, 56, 50, 65)
#' bmi <- c(23, 28, 26, 27, 24, 23, 26)
#' smkstatus <- c(2, 2, 1, 1, 1, 2, 1)
#' cpd <- c(36, 36, 40, 24, 40, 10, 5)
#' emp <- c(0, 1, 1, 0, 1, 1, 0)
#' copd <- c(0, 1, 1, 0, 1, 1, 0)
#' fam.lung.trend <- c(0, 2, 0, 2, 0, 2, 0)
#' female <- c(0, 1, 0, 1, 0, 1, 0)
#' smkyears <- c(43, 37, 45, 42, 29, 15, 30)
#' qtyears <- c(0, 0, 9, 6, 6, 0, 5)
#' race <- c(0, 1, 2, 2, 3, 3, 3)
#' edu6 <- c(3, 5, 4, 5, 5, 4, 2)
#' asb <- c(0, 0, 0, 0, 0, 0, 0)
#' pneu <- c(0, 0, 0, 0, 0, 0, 0)
#' prior.cancer <- c(0, 0, 0, 0, 0, 0, 0)
#' fam.cancer.onset <- c(0, 1, 0, 2, 0, 0, 0)
#' dust <- c(0, 0, 0, 0, 0, 0, 0)
#' fam.cancer <- c(0, 1, 0, 1, 0, 0, 0)
#' fam.smoke.cancer <- c(0, 1, 0, 1, 0, 0, 0)
#' no.hayfever <- c(1, 1, 1, 1, 1, 1, 0)
#' asian <- c(0, 0, 0, 0, 1, 1, 1)
#' islander <- c(0, 0, 0, 0, 0, 0, 0)
#' indian <- c(0, 0, 0, 0, 0, 0, 0)
#' ets <- c(0, 0, 0, 0, 0, 0, 0)
#' smkexp <- c(2, 3, 5, 1, 0, 3, 2)
#' bron <- c(0, 0, 0, 0, 0, 0, 0)
#' activity <- c(1, 3, 2, 1, 2, 1, 1)
#' low.activity <- c(0, 1, 1, 0, 0, 0, 0)
#' diabetes <- c(1, 0, 0, 1, 1, 0, 1)
#' glucose <- c(130, 115, 101, 145, 126, 120, 135)
#' cough.daily <- c(0, 1, 0, 1, 0, 1, 1)
#' height <- c(160, 170, 183, 164, 172, 169, 180)
#' urban <- c(1, 1, 0, 1, 0, 0, 0)
#' frequent.cough <- c(0, 1, 0, 1, 0, 1, 1)
#' smk.into.lung <- c(0, 0, 1, 1, 0, 1, 1)
#'
#' persons <- data.frame(
#'   age,
#'   female,
#'   smkstatus,
#'   smkyears,
#'   qtyears,
#'   cpd,
#'   race,
#'   emp,
#'   fam.lung.trend,
#'   bmi,
#'   edu6,
#'   asb,
#'   pneu,
#'   prior.cancer,
#'   fam.cancer.onset,
#'   copd,
#'   dust,
#'   fam.cancer,
#'   fam.smoke.cancer,
#'   no.hayfever,
#'   asian,
#'   islander,
#'   indian,
#'   ets,
#'   smkexp,
#'   bron,
#'   activity,
#'   low.activity,
#'   diabetes,
#'   glucose,
#'   cough.daily,
#'   height,
#'   urban,
#'   frequent.cough,
#'   smk.into.lung
#' )
#'
#' individualPred_plot(persons[1,])

individualPred_plot <- function(data,language = 1) {
  # Check if the input data is non-empty
  if (!length(data)) stop("ERROR: input data has length 0")

  # Ensure the input data is either a matrix or a data frame
  if (!is.data.frame(data) && !is.matrix(data)) stop("ERROR: input data must be a matrix or data frame")

  # Check if the input data has only one row
  if (nrow(data) != 1) stop(paste0("ERROR: input data must have only 1 row"))

  lung.cancer.risk <- t(lcrisks(data))

  # Define threshold values for various models
  thre.bach <- 0.0217
  thre.hoggart <- NA
  thre.llpv3 <- 0.025 # from article
  thre.llpi <- 0.037
  thre.spitz <- NA
  thre.plcom2012 <- 0.0151 # from article
  thre.plcoall2014 <- 0.0151 # from article
  thre.pittsburgh <- 0.017 # from article
  thre.lcrat <- 0.020 # from author
  thre.koreanmen <- 0.0316
  thre.hunt <- 0.0064 # from article
  thre.lcrs <- ifelse(data[, 3] == 0, 1 - 0.994893**exp((0.122 * (21.2 - 14.7))),
                      ifelse(data[, 3] == 1 | data[, 3] == 2, 1 - 0.987736**exp((0.022 * (166.2 - 157.3))), NA)
  ) # from article
  thre.owl <- 0.00303 # from article

  # Create a data frame for the risk prediction results
  risk.predict <- data.frame(
    model <- c(
      "Spitz", "Hoggart", "LCRAT", "LLPv3", "PLCOm2012",
      "PLCOall2014", "Pittsburgh", "HUNT", "Korean Men", "OWL",
      "LLPi", "Bach", "LCRS"
    ),
    risk = lung.cancer.risk,
    risk.label = ifelse(is.na(lung.cancer.risk), "unkown", paste(sprintf("%.2f", lung.cancer.risk * 100), "%")),
    threshold = c(
      thre.spitz, thre.hoggart, thre.lcrat, thre.llpv3, thre.plcom2012,
      thre.plcoall2014, thre.pittsburgh, thre.hunt, thre.koreanmen, thre.owl,
      thre.llpi, thre.bach, thre.lcrs
    ),
    risk.year <- c(1, 1, 5, 5, 6, 6, 6, 6, 8, 8, 8.7, 10, 10)
  )

  risk.predict <- risk.predict[!is.na(lung.cancer.risk), ]

  # Calculate the fraction for each part of the chart
  risk.predict$fraction <- rep(1 / nrow(risk.predict), nrow(risk.predict))

  # Calculate the y-axis position for each part
  risk.predict$ymax <- cumsum(risk.predict$fraction)
  risk.predict$ymin <- c(0, head(risk.predict$ymax, n = -1))

  # Assign risk level based on the comparison of actual value and threshold value
  risk.predict$risk.level <- ifelse(is.na(risk.predict$risk) | is.na(risk.predict$threshold), "unkown",
                                    ifelse(risk.predict$risk >= risk.predict$threshold, "high", "low")
  )

  checkInt(language, "language", min = 1, max = 2)

  if (language == 2) {
    # Plot the circular bar chart
    p1 <- ggplot(risk.predict, aes(ymax = ymax, ymin = ymin, xmax = 4, xmin = 2.75)) +
      geom_rect(aes(fill = risk.level), color = "white", size = 1) +
      theme_void() +
      xlim(1, 4) +
      coord_polar(theta = "y") +
      geom_text(aes(x = 3.45, y = (ymax + ymin) / 2, label = paste(model, "模型", "\n", risk.year, "年风险", "\n", risk.label)), size = 4, fontface = "bold", color = "white") + # Add labels to the chart
      scale_fill_manual(
        values = c("low" = "#42B540", "high" = "#ED0000", "unkown" = "#ADB6B6"), # 自定义颜色
        breaks = c("low", "high"),
        labels = c("low" = "低风险", "high" = "高风险") # 设置图例标签
      ) +
      labs(fill = "风险等级") +
      theme(
        plot.title = element_text(hjust = 0.5),
        legend.title = element_text(size = 24, face = "bold"),
        legend.text = element_text(size = 20),
        legend.key.size = unit(1, "cm"),
        legend.position = c(0.5, 0.5)
      )

    # Create a text annotation for additional information
    p2 <- ggplot() +
      theme_void() +
      theme(plot.margin = margin(0, 0, 0.5, 0, "cm")) +
      annotate("text",
               x = 0, y = 0,
               label = paste0(
                 "一共使用了", nrow(risk.predict), "个肺癌风险预测模型进行预测, \n",
                 "其中", sum(risk.predict$risk.level == "high"), "个提示您有高风险,",
                 sum(risk.predict$risk.level == "low"), "个提示您风险较低,\n",
                 sum(risk.predict$risk.level == "unkown"), "个模型信息不足或不适用。"
               ),
               size = 6, color = "black"
      )

    # Create a layout for the plots
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(2, 1, heights = c(7, 1)))) # Create a 2-row layout

    # Insert the plots into the layout
    print(p1, vp = viewport(layout.pos.row = 1)) # Print p1 in row 1
    print(p2, vp = viewport(layout.pos.row = 2)) # Print p2 in row 2

    # Record the plot for later use
    p <- recordPlot()
    p
  } else if (language == 1) {
    p1 <- ggplot(risk.predict, aes(ymax = ymax, ymin = ymin, xmax = 4, xmin = 2.75)) +
      geom_rect(aes(fill = risk.level), color = "white", size = 1) +
      theme_void() +
      xlim(1, 4) +
      coord_polar(theta = "y") +
      geom_text(aes(x = 3.45, y = (ymax + ymin) / 2, label = paste(model, "\n", risk.year, "year risk", "\n", risk.label)), size = 4, fontface = "bold", color = "white") + # Add labels to the chart
      scale_fill_manual(
        values = c("low" = "#42B540", "high" = "#ED0000", "unkown" = "#ADB6B6"), # 自定义颜色
        breaks = c("low", "high"),
        labels = c("low" = "low risk", "high" = "high risk") # 设置图例标签
      ) +
      labs(fill = "risk level") +
      theme(
        plot.title = element_text(hjust = 0.5),
        legend.title = element_text(size = 24, face = "bold"),
        legend.text = element_text(size = 20),
        legend.key.size = unit(1, "cm"),
        legend.position = c(0.5, 0.5)
      )

    p2 <- ggplot() +
      theme_void() +
      theme(plot.margin = margin(0, 0, 0.5, 0, "cm")) +
      annotate("text",
               x = 0, y = 0,
               label = paste0(
                 "A total of ", nrow(risk.predict), " lung cancer risk prediction models were used, \n",
                 "among which ", sum(risk.predict$risk.level == "high"), " indicate high risk, ",
                 sum(risk.predict$risk.level == "low"), " indicate low risk, \n",
                 sum(risk.predict$risk.level == "unkown"), " models have insufficient or inapplicable information."
               ),
               size = 6, color = "black"
      )
  }
  # Create a layout for the plots
  grid.newpage()
  pushViewport(viewport(layout = grid.layout(2, 1, heights = c(7, 1)))) # Create a 2-row layout

  # Insert the plots into the layout
  print(p1, vp = viewport(layout.pos.row = 1))  # Print p1 in row 1
  print(p2, vp = viewport(layout.pos.row = 2))  # Print p2 in row 2

  # Record the plot for later use
  p <- recordPlot()
  p
}
